//
//  SkyIdSDK.h
//  SkyIdSDK
//
//  Created by mac pro on 17/07/2020.
//  Copyright © 2020 IDC. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SkyIdSDK.
FOUNDATION_EXPORT double SkyIdSDKVersionNumber;

//! Project version string for SkyIdSDK.
FOUNDATION_EXPORT const unsigned char SkyIdSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SkyIdSDK/PublicHeader.h>


